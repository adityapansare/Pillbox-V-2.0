package com.amplify.pillbox;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Random;

public class AdminActivity extends AppCompatActivity {


    EditText DrugName,drugQty,drugPrice;
    int qty;
    String price,name;
    Button AddUpdate;



    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        DrugName = findViewById(R.id.DrugNameET);
        drugPrice = findViewById(R.id.DrugPriceET);
        drugQty = findViewById(R.id.DrugQtyET);
        AddUpdate = findViewById(R.id.AddUpdateButton);

        //Drug drug;
        firebaseDatabase = FirebaseDatabase.getInstance();

        databaseReference = firebaseDatabase.getReference("drugs");

        AddUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random rand =new Random();
               final  Drug drug = new Drug(""+(rand.nextInt(5000)),DrugName.getText().toString()
                ,drugPrice.getText().toString(),Integer.parseInt(drugQty.getText().toString()));

                databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {





                        firebaseDatabase.getReference("drugs").push().setValue(drug);


                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        });



    }
}
