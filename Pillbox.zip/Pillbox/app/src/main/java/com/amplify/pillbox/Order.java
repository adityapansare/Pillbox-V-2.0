package com.amplify.pillbox;

/**
 * Created by adity on 22-04-2018.
 */

public class Order {
    private String orderId;
    private int tPrice;

    public Order(String orderId, int tPrice) {
        this.orderId = orderId;
        this.tPrice = tPrice;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public int gettPrice() {
        return tPrice;
    }

    public void settPrice(int tPrice) {
        this.tPrice = tPrice;
    }
}
