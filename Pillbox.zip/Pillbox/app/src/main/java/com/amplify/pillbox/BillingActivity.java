package com.amplify.pillbox;

import android.content.Intent;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class BillingActivity extends AppCompatActivity {

    ListView checkOutList ;
    int price;
    //ArrayList<Drug> CheckOutDrugList = new ArrayList<Drug>();
    String[] CheckOutDrugName ;
    String[] CheckOutDrugPrice;
    String[] CheckOutDrugQty;
    String[] CheckOutDrugID;
    String[] CheckDifference;
    ArrayList<String> TotalPriceQty = new ArrayList<String>();
    ArrayList<String> OrderedQty = new ArrayList<String>();
    FirebaseDatabase firebaseDatabase;
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    Button placeOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setTheme(R.style.PillboxGreenTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_billing);
        Intent intent = getIntent();
        int Counter = intent.getIntExtra("Counter",0);
        CheckOutDrugName = intent.getStringArrayExtra("DrugsOnOrderName");
        CheckOutDrugQty = intent.getStringArrayExtra("DrugsOnOrderQty");
        CheckOutDrugPrice = intent.getStringArrayExtra("DrugsOnOrderPrice");
        CheckOutDrugID = intent.getStringArrayExtra("DrugsOnOrderID");
        OrderedQty = intent.getStringArrayListExtra("QtyValues");
        CheckDifference = intent.getStringArrayExtra("DrugDifference");
        ListView billingList = findViewById(R.id.CheckoutWindowList);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        firebaseDatabase = FirebaseDatabase.getInstance();
        checkOutList = findViewById(R.id.CheckoutWindowList);



/*

        i =0;
        for(String id : CheckOutDrugID){
            d[i].drugId = id;
            i++;
        }

        i =0;
        for(String name : CheckOutDrugName){
            d[i].drugName = name;
            i++;
        }

        i =0;
        for(int qty : CheckOutDrugQty){
            d[i].drugQty = qty;
            i++;
        }

        for(i=0;i<OrderedQty.size();i++){
            TotalPriceQty.add("" + ((Integer.parseInt(OrderedQty.get(i))) * (Integer.parseInt(d[i].drugPrice))));
        }

        String[] DrugName = CheckOutDrugName.toArray(new String[CheckOutDrugName.size()]);
        String[] DrugPrice = TotalPriceQty.toArray(new String[TotalPriceQty.size()]);
        String[] DrugOrderedQty = OrderedQty.toArray(new String[OrderedQty.size()]);*/


        CustomListViewAdapter customListViewAdapter = new CustomListViewAdapter(this,
                CheckOutDrugName, CheckOutDrugQty,CheckOutDrugPrice);
        billingList.setAdapter(customListViewAdapter);

        TextView priceShow = findViewById(R.id.TotalPrice);
        price=0;
        for(int i=0;i<Counter;i++){
            price=price + Integer.parseInt(CheckOutDrugPrice[i]);
        }
        String m = ""+price;
        priceShow.setText(getString(R.string.rupee_symbol)+" "+m);
        placeOrder = findViewById(R.id.PlaceOrderButton);
        placeOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int totalPrice = price;
                Calendar c = Calendar.getInstance();
                System.out.println("Current time => "+c.getTime());

                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String formattedDate = df.format(c.getTime());
                Order order = new Order(formattedDate,totalPrice);
                firebaseDatabase.getReference("users").child(firebaseUser.getUid()).child("orders").child(order.getOrderId()).setValue(order);
                Toast.makeText(BillingActivity.this, "Order history was added for user", Toast.LENGTH_SHORT).show();
                // formattedDate have current date/time
               // Toast.makeText(BillingActivity.this, formattedDate, Toast.LENGTH_SHORT).show();
                //for(int i =0;i<CheckOutDrugID.length;i++){
                //    firebaseDatabase.getReference("drugs").child(CheckOutDrugID[i]).child("drugQty").setValue(Integer.parseInt(CheckDifference[i]));
                //}
                Intent intent = new Intent(BillingActivity.this,SuccessScreen.class);
                Bundle bundle = new Bundle();

                bundle.putString("OrderID",order.getOrderId());
                intent.putExtra("Bundle",bundle);
                startActivity(intent);
                finish();

            }
        });










    }
}
