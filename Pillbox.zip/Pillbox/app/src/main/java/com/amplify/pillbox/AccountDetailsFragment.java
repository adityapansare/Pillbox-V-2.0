package com.amplify.pillbox;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


/**
 * A simple {@link Fragment} subclass.
 */
public class AccountDetailsFragment extends Fragment {
    FirebaseDatabase firebaseDatabase;
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    TextView name;
    TextView age;
    TextView email;
    TextView phone;
    User currUser;
    public AccountDetailsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account_details, container, false);
        firebaseDatabase=FirebaseDatabase.getInstance();
        firebaseAuth= FirebaseAuth.getInstance();
        firebaseUser= firebaseAuth.getCurrentUser();
        final String userID = firebaseUser.getUid();
        name = view.findViewById(R.id.nameDetailsCard);
        age = view.findViewById(R.id.ageLabel);
        email = view.findViewById(R.id.emailLabel);
        phone = view.findViewById(R.id.phoneLabel);

        firebaseDatabase.getReference("users").child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                currUser = dataSnapshot.getValue(User.class);
                //Toast.makeText(getContext(), currUser.firstName, Toast.LENGTH_SHORT).show();
                age.setText("" + currUser.age);
                email.setText(currUser.email);
                phone.setText("+91-"+currUser.phone);
                name.setText(currUser.firstName + " " + currUser.lastName);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });



        // Inflate the layout for this fragment
        return view;

    }

}
