package com.amplify.pillbox;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.firebase.database.IgnoreExtraProperties;

/**
 * Created by Aditya on 27-03-2018.
 */

@IgnoreExtraProperties
public class Drug implements Parcelable {
    public String drugId;
    public String drugName;
    public String drugPrice;
    public int drugQty;

    @Override
    public int describeContents() {
        return 0;
    }

    public Drug(Parcel in) {
        drugId = in.readString();
        drugName = in.readString();
        drugPrice = in.readString();
        drugQty = in.readInt();

    }

    public static final Parcelable.Creator<Drug> CREATOR = new Parcelable.Creator<Drug>() {
        public Drug createFromParcel(Parcel in) {
            return new Drug(in);
        }
        public Drug[] newArray(int size) {
            return new Drug[size];

        }
    };


        @Override
    public void writeToParcel(Parcel dest, int flags) {

    }

    public Drug() {
        //default necessary for firebase;
    }

    public Drug(String drugId, String drugName, String drugPrice, int drugQty) {
        this.drugId = drugId;
        this.drugName = drugName;
        this.drugPrice = drugPrice;
        this.drugQty = drugQty;
    }

    public String getDrugId() {
        return drugId;
    }

    public void setDrugId(String drugId) {
        this.drugId = drugId;
    }

    public String getDrugName() {
        return drugName;
    }

    public void setDrugName(String drugName) {
        this.drugName = drugName;
    }

    public String getDrugPrice() {
        return drugPrice;
    }

    public void setDrugPrice(String drugPrice) {
        this.drugPrice = drugPrice;
    }

    public int getDrugQty() {
        return drugQty;
    }

    public void setDrugQty(int drugQty) {
        this.drugQty = drugQty;
    }
}
