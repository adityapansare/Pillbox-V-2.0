package com.amplify.pillbox;


import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.text.style.BackgroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class PlaceOrderFragment extends Fragment {


    Activity Context;
    boolean canSubmit=false;
    public ListView CustomList;
    private List<String> DrugNameInformation = new ArrayList<String>();
    Drug data;
    int qtyCount = 0;
    String productPrice;
    ArrayList<String> differenceGeneratorQty = new ArrayList<String>();

    ArrayList<String> DrugNameList = new ArrayList<String>();
    ArrayList<String> DrugSelectIds = new ArrayList<String>();
    ArrayList<Drug> DrugsListCart = new ArrayList<Drug>();
    ArrayList<String> DrugQtyList = new ArrayList<String>();
    ArrayList<String> DrugPriceList = new ArrayList<String>();
    //adapters and spinners initialised;
    Spinner spinner;
    private ArrayAdapter<String> drugAdapter;

    //firebase initialisations
    private FirebaseDatabase firebaseDatabase;
    private DataSnapshot firstDataSnapshot = null;

    String[] DrugName;
    String[] DrugQty;
    String[] DrugPrice;
    String[] DrugIds;
    String[] differenceGeneratorQtyArray;
    //layout initialisations
    TextView DrugPriceShow;
    Button AddButton,SubmitButton,ClearButton;
    TextView Plus, Minus;
    EditText valueTextEdit;

    public PlaceOrderFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_place_order, container, false);
        AddButton = view.findViewById(R.id.buttonPlaceOrderAdd);
        CustomList = view.findViewById(R.id.CartList);
        SubmitButton = view.findViewById(R.id.buttonPlaceOrderSubmit);
        ClearButton = view.findViewById(R.id.buttonPlaceOrderClear);
        firebaseDatabase = FirebaseDatabase.getInstance();
        valueTextEdit = view.findViewById(R.id.valueEditText);
        DatabaseReference drugIdRef = firebaseDatabase.getReference("drugs");
        Plus = view.findViewById(R.id.plusButton);
        Minus = view.findViewById(R.id.minusButton);
        DrugPriceShow = view.findViewById(R.id.DrugPriceShow);
        drugAdapter = new ArrayAdapter<String>(getActivity(), R.layout.pillbox_simple_spinner_item, DrugNameInformation);
        drugAdapter.setDropDownViewResource(R.layout.pillbox_spinner_dropdown_layout);
        spinner = (Spinner) view.findViewById(R.id.drugNameSpinner);
        spinner.setAdapter(drugAdapter);
        spinner.setBackgroundColor(Color.alpha(1));


        if (DrugNameInformation.isEmpty()) {        //trigger only first time fragment is created, when list is empty;

            drugIdRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    firstDataSnapshot = dataSnapshot;
                    for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {
                        String drugIDkey = childSnapshot.getKey();

                        /**
                         * Right now, the below line does the job perfectly fine.
                         */
                        data = childSnapshot.getValue(Drug.class);
                        //data.setDrugId(childSnapshot.getKey());
                        //data.setDrugName(childSnapshot.child("drugName").getValue().toString());
                        //data.setDrugPrice(childSnapshot.child("drugPrice").getValue().toString());
                        //data.setDrugQty(Integer.parseInt(childSnapshot.child("drugQty").getValue().toString()));
                        DrugNameInformation.add(data.getDrugName());
                    }
                    drugAdapter.notifyDataSetChanged();
                }


                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
            DrugPriceShow.setText(getString(R.string.rupee_symbol));
        } else {
            Log.d("Drug info", "List was already populated; not adding");
        }

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String productSelected = adapterView.getSelectedItem().toString();
                String productSelectedPrice = "0.00";
                for (DataSnapshot childDataSnapshot : firstDataSnapshot.getChildren()) {
                    if (productSelected == childDataSnapshot.child("drugName").getValue().toString()) {
                        data = childDataSnapshot.getValue(Drug.class);

                        //Toast.makeText(getContext(), "Product found in list!", Toast.LENGTH_SHORT).show();
                        productPrice = childDataSnapshot.child("drugPrice").getValue().toString();
                        DrugPriceShow.setText(getString(R.string.rupee_symbol) + " ");
                        break;
                    } else {
                        continue;
                    }
                }
            }


            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        ClearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Log.d("CLR","Chal Raha Hai);");
                    String deleter =""+data.drugName;

                    Toast.makeText(getContext(),""+deleter,Toast.LENGTH_SHORT).show();

                    for(int i =0; i<DrugNameList.size();i++){
                        String b = DrugNameList.get(i);
//                        Toast.makeText(getContext(),"Dekh pehele "+DrugNameList.get(i),Toast.LENGTH_SHORT).show();

                        if(b.equals(deleter)){
  //                          Toast.makeText(getContext(),"Dekh "+DrugNameList.get(i),Toast.LENGTH_SHORT).show();
                            DrugNameList.remove(i);
                            DrugQtyList.remove(i);
                            DrugPriceList.remove(i);
                            i=0;
                        }else {
    //                        Toast.makeText(getContext(),"Not Clear ",Toast.LENGTH_SHORT).show();
                        }
                    }


                    if(DrugNameList.size()==0){
                        canSubmit= false;
                    }
                    DrugQty = DrugQtyList.toArray(new String[DrugQtyList.size()]);
                    DrugName = DrugNameList.toArray(new String[DrugNameList.size()]);
                    DrugPrice = DrugPriceList.toArray(new String[DrugPriceList.size()]);

                Context = getActivity();
                    CustomListViewAdapter customListViewAdapter = new CustomListViewAdapter(Context,
                            DrugName, DrugQty, DrugPrice);
                    CustomList.setAdapter(customListViewAdapter);
                }

        });

        Plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qtyCount += 1;
                DrugPriceShow.setText(getString(R.string.rupee_symbol) + " " + qtyCount * Integer.parseInt(productPrice));
                valueTextEdit.setText("" + qtyCount);

            }
        });
        Minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qtyCount -= 1;
                if (qtyCount >= 0) {
                    DrugPriceShow.setText(getString(R.string.rupee_symbol) + " " + qtyCount * (Integer.parseInt(productPrice)));
                    valueTextEdit.setText("" + qtyCount);
                }else{
                    qtyCount=0;
                    DrugPriceShow.setText(getString(R.string.rupee_symbol) + " " + 0 * (Integer.parseInt(productPrice)));
                    valueTextEdit.setText("" + qtyCount);
                }
            }
        });

        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!valueTextEdit.getText().toString().equals("0")) {
                    canSubmit = true;
                    DrugsListCart.add(data);

                    DrugSelectIds.add(data.drugId);
                    DrugNameList.add("" + data.drugName);
                    DrugName = DrugNameList.toArray(new String[DrugNameList.size()]);
                    if (Integer.parseInt(valueTextEdit.getText().toString()) < data.drugQty) {


                        String tempPriceandQty = "" + (Integer.parseInt(data.drugPrice)
                                * Integer.parseInt(valueTextEdit.getText().toString()));

                        //Quantity
                        DrugQtyList.add("" + valueTextEdit.getText().toString());
                        differenceGeneratorQty.add(""+(data.drugQty-Integer.parseInt(valueTextEdit.getText().toString())));
                        differenceGeneratorQtyArray = differenceGeneratorQty.toArray(new String[differenceGeneratorQty.size()]);
                        DrugQty = DrugQtyList.toArray(new String[DrugQtyList.size()]);
                        // Price
                        DrugPriceList.add(""+tempPriceandQty);
                        DrugPrice = DrugPriceList.toArray(new String[DrugPriceList.size()]);

                        DrugIds = DrugSelectIds.toArray(new String[DrugSelectIds.size()]);
                        Context = getActivity();
                        CustomListViewAdapter customListViewAdapter = new CustomListViewAdapter(Context,
                                DrugName, DrugQty, DrugPrice);
                        CustomList.setAdapter(customListViewAdapter);

                        valueTextEdit.setText("0");
                        DrugPriceShow.setText(getString(R.string.rupee_symbol)+"0");
                        qtyCount =0;
                    } else {
                        Toast.makeText(getContext(), "Out of Stock", Toast.LENGTH_SHORT).show();
                        valueTextEdit.setText("0");
                        DrugPriceShow.setText(getString(R.string.rupee_symbol)+" 0");
                    }
                }else {
                    Toast.makeText(getContext(),"Select a Product",Toast.LENGTH_SHORT).show();
                }
            }
        });

        SubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(canSubmit==true){


                    Intent intent = new Intent(getContext(),BillingActivity.class);
                    int c;
                    c = DrugNameList.size();
                    intent.putExtra("Counter",c);
                    intent.putExtra("DrugsOnOrderName",DrugName);
                    intent.putExtra("DrugsOnOrderPrice",DrugPrice);
                    intent.putExtra("DrugsOnOrderQty",DrugQty);
                    intent.putExtra("QtyValues",DrugQtyList);
                    intent.putExtra("DrugOnOrderID",DrugIds);

                    intent.putExtra("DrugDifference",differenceGeneratorQtyArray);
                    startActivity(intent);
                }else{
                    Toast.makeText(getContext(),"Cart is empty",Toast.LENGTH_SHORT).show();
                }
            }
        });
        return view;
    }

}
