package com.amplify.pillbox;


import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class OrderHistoryFragment extends Fragment {

    Activity Context;
    Order order;

    FirebaseDatabase firebaseDatabase;
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;

    ArrayList<String> OrderId = new ArrayList<String>();
    ArrayList<String> OrderPrice = new ArrayList<String>();
    //DataSnapshot orderDataSnapshot;
    public OrderHistoryFragment() {
        // Required empty public constructor
    }
    ListView CustomList;
    String[] orderId;
    String[] orderPrice;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        firebaseDatabase = FirebaseDatabase.getInstance();
        //DataSnapshot orderDataSnapshot = null;

        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_order_history, container, false);



        Context = getActivity();




        firebaseDatabase.getReference("users").child(firebaseUser.getUid()).child("orders").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot orderDataSnapshot : dataSnapshot.getChildren()){
                    DataSnapshot innerOrderDataSnapshot = orderDataSnapshot.child("orderId");
                    String test1 =innerOrderDataSnapshot.getValue().toString();

                    OrderId.add(test1);

                    innerOrderDataSnapshot = orderDataSnapshot.child("tPrice");
                    //Toast.makeText(getContext(), innerOrderDataSnapshot.toString(), Toast.LENGTH_LONG).show();
                    String test2 = innerOrderDataSnapshot.getValue().toString();
                    OrderPrice.add(test2);

                    String[] OrderIDS = OrderId.toArray(new String[OrderId.size()]);
                    String[] OrderPrices = OrderPrice.toArray(new String[OrderPrice.size()]);
                    CustomList = view.findViewById(R.id.ListViewOrder);
                    CustomListViewAdapter customListViewAdapter =new CustomListViewAdapter(Context,
                            OrderIDS, OrderPrices,null);

                    CustomList.setAdapter(customListViewAdapter);


                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });

        return view;
    }

}
