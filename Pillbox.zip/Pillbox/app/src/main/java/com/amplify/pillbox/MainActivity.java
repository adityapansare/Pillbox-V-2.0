package com.amplify.pillbox;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class MainActivity extends AppCompatActivity {

    EditText email;
    EditText password;
    TextView close;
    Button sign_up;
    Button sign_in;
    ProgressBar progress;
    RelativeLayout home_layout;



    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase firebaseDatabase;
    private FirebaseUser firebaseUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       /*try {
            ConnectivityManager connectivityManager =
                    (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();

            if (activeNetwork.isConnected()==false) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Error")
                        .setMessage("Check your Internet connection");
                builder.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        recreate();
                    }

                });
            }
        }
            catch (Exception e) {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Error")
                    .setMessage("Check your Internet connection");
            builder.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    recreate();
                }
            });

            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });

            AlertDialog errorDialog = builder.create();
            errorDialog.show();
        }*/


        email = (EditText) findViewById(R.id.EmailEditText);
        password = (EditText) findViewById(R.id.PasswordEditText);
        close = (TextView) findViewById(R.id.CloseActivityCross);
        sign_up = (Button) findViewById(R.id.mainSignUpButton);
        sign_in = (Button) findViewById(R.id.mainSignInButton);
        home_layout = findViewById(R.id.homeLayout);
        progress = findViewById(R.id.MainActivityProgressBar);

        //get Firebase auth instance;
        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Closing", Toast.LENGTH_SHORT).show();
                MainActivity.this.finish();
                Log.d("Cross:", "Activity closed");
            }
        });

        sign_in.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View view) {
                String emailId = email.getText().toString().trim();
                String pwd = password.getText().toString().trim();
                progress.setVisibility(View.VISIBLE);

                if (TextUtils.isEmpty(emailId) || TextUtils.isEmpty(pwd) ) {
                    Toast.makeText(MainActivity.this, "Please enter a valid email address!", Toast.LENGTH_SHORT).show();
                    return;
                }else {

                    //if (TextUtils.isEmpty(pwd)) {
                    //   Toast.makeText(MainActivity.this, "Please enter a password", Toast.LENGTH_SHORT).show();
                    //} else if (password.length() < 6) {
                    //  Toast.makeText(MainActivity.this, "Password at least 6 characters", Toast.LENGTH_SHORT).show();
                    //}


                    //create user;
                    Task<AuthResult> authResultTask = firebaseAuth.signInWithEmailAndPassword(emailId, pwd).addOnCompleteListener(MainActivity.this,
                            new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    progress.setVisibility(View.INVISIBLE);

                                    if (!task.isSuccessful()) {
                                        //Failure
                                        Toast.makeText(MainActivity.this, "Authentication Failed.\nCheck Credentials again.", Toast.LENGTH_LONG).show();
                                    } else {
                                        //Success
                                        firebaseUser = firebaseAuth.getCurrentUser();
                                        final String userId = firebaseUser.getUid();
                                        //Toast.makeText(MainActivity.this, "Signed in as " + firebaseUser.getUid(), Toast.LENGTH_LONG).show();
                                        firebaseDatabase.getReference("admins").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(DataSnapshot dataSnapshot) {
                                                //Toast.makeText(MainActivity.this,"Data retrieved = " + (String)dataSnapshot.getValue().toString(),Toast.LENGTH_SHORT).show();
                                                String isAdmin = dataSnapshot.getValue().toString();
                                                if (isAdmin == "true") {

                                                    Intent switchToAdmin = new Intent(MainActivity.this, AdminActivity.class);
                                                    startActivity(switchToAdmin);
                                                    Toast.makeText(MainActivity.this, "Admin user, Signed in", Toast.LENGTH_SHORT).show();

                                                } else {

                                                    Intent intent = new Intent(MainActivity.this, CustomerActivity.class);
                                                    Bundle bundle = new Bundle();
                                                    bundle.putString("userId", firebaseUser.getUid());
                                                    intent.putExtras(bundle);
                                                    startActivity(intent);
                                                    finish();
                                                }
                                            }

                                            public void onCancelled(DatabaseError databaseError) {

                                            }
                                        });
                                    }

                                }
                            });
                }

            }
        });


        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signUpIntent = new Intent(MainActivity.this, SignUpActivity.class);
                startActivity(signUpIntent);
                Log.d("SIGN UP TRIGGERED", "User did not have an account. Launched sign up activity.");
            }
        });
    }

    @Override
    protected void onResume() {
        MainActivity.super.onResume();
        progress.setVisibility(View.GONE);
    }


}
 /*       if (!task.isSuccessful()) {
                            Toast.makeText(MainActivity.this, "Could not sign in!", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Signed in as " + firebaseAuth.getCurrentUser().getEmail(), Toast.LENGTH_LONG).show();
                            FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
                            final String userId = firebaseUser.getUid();
                            firebaseDatabase.getReference("admins").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    String isAdmin = dataSnapshot.getValue().toString();
                                    if (isAdmin == "true") {

                                            /TODO:
                                        //Add action for admin activity;

                                        Intent switchToAdmin = new Intent(MainActivity.this, AdminActivity.class);
                                        startActivity(switchToAdmin);
                                        Toast.makeText(MainActivity.this, "Admin user!", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Intent intent = new Intent(MainActivity.this, CustomerActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putString("userId", userId);
                                        intent.putExtras(bundle);
                                        startActivity(intent);
                                    }
                                }


                            }*/