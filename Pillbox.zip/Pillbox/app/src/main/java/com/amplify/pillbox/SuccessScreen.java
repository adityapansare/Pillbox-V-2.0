package com.amplify.pillbox;

import android.content.Intent;
import android.os.Handler;
import android.support.v4.app.SupportActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class SuccessScreen extends AppCompatActivity {
    private static int TIME_OUT = 4000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success_screen);

        Intent intent  = getIntent();
        Bundle bundle = intent.getExtras();
        String orderId=bundle.getString("OrderID");



        ImageView SuccessCheck = (ImageView) findViewById(R.id.successCheck);
        TextView successText = (TextView) findViewById(R.id.successString);
        SuccessCheck.animate().alpha(1f).setDuration(3000);
        successText.animate().translationY(-450f).setDuration(2000).alpha(1f);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, TIME_OUT);
        /*PlaceOrderFragment fragment = (PlaceOrderFragment) getSupportFragmentManager().getFragments().get(0);
        getSupportFragmentManager().beginTransaction()
                .detach(fragment)
                .attach(fragment)
                .commit();*/
    }

}
