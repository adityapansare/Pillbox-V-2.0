package com.amplify.pillbox;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * Created by Aditya on 16-04-2018.
 */

public class PillboxValueSelector extends RelativeLayout {

    //declaring components;
    View rootView;
    TextView valueTextView;
    View minusButton;
    View plusButton;
    private int minVal = Integer.MIN_VALUE;
    private int maxVal = Integer.MAX_VALUE;

    public int getMinVal() {
        return minVal;
    }

    public void setMinVal(int minVal) {
        this.minVal = minVal;
    }

    public int getMaxVal() {
        return maxVal;
    }

    public void setMaxVal(int maxVal) {
        this.maxVal = maxVal;
    }

    public int getValue() {
        return Integer.valueOf(valueTextView.getText().toString());
    }

    public PillboxValueSelector(Context context) {
        super(context);
        init(context);
    }

    public PillboxValueSelector(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public PillboxValueSelector(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    public PillboxValueSelector(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    public void setValue(int newValue) {
        int value = newValue;
        if (newValue < minVal) {
            value = minVal;
        } else if (newValue > maxVal) {
            value = maxVal;
        }

        valueTextView.setText(String.valueOf(value));
    }

    private void init(Context context) {
        rootView = inflate(context, R.layout.pillbox_value_selector, this);
        valueTextView = rootView.findViewById(R.id.valueEditText);
        minusButton = rootView.findViewById(R.id.minusButton);
        plusButton = findViewById(R.id.plusButton);

        minusButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                decrementValue();
            }

            private void decrementValue() {
                int currentVal = Integer.valueOf(valueTextView.getText().toString());
                if (currentVal > minVal) {
                    valueTextView.setText(String.valueOf(currentVal - 1));
                }
            }
        });

        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                incrementValue();
            }

            private void incrementValue() {
                int currentVal = Integer.valueOf(valueTextView.getText().toString());
                if (currentVal < maxVal) {
                    valueTextView.setText(String.valueOf(currentVal + 1));}
            }
        });
    }
}
