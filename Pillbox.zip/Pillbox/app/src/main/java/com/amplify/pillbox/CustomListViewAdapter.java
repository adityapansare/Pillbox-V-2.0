package com.amplify.pillbox;

import android.app.Activity;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

/**
 * Created by adity on 18-04-2018.
 */

public class CustomListViewAdapter extends ArrayAdapter<String> {

    private Activity context;
    private String[] component1;
    private String[] component2;
    private String[] component3;



    public CustomListViewAdapter(Activity context, String[] component1, String[] component2, String[] component3){
        super(context, R.layout.custom_listview_components, component1);
        this.context = context;
        this.component1 = component1;
        this.component2 = component2;
        this.component3 = component3;
    }
    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.custom_listview_components, null,true);

        TextView bigComponent = (TextView)rowView.findViewById(R.id.BigTextlistView);
        TextView smallComponent = (TextView) rowView.findViewById(R.id.SmallTextListView);
        TextView smallercomponent = (TextView) rowView.findViewById(R.id.SmallerTextListView) ;

        if(component3 == null) {
            bigComponent.setText("Date & Time: " +component1[position]);
            smallComponent.setText("Price: "+component2[position]);
            smallercomponent.setText("");
        }else{
            bigComponent.setText("Drug Name: "+component1[position]);
            smallComponent.setText("Quantity: "+component2[position]);
            smallercomponent.setText("Price: "+component3[position]);
        }


        return rowView;
    };
}
