package com.amplify.pillbox;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CustomerActivity extends AppCompatActivity {

    //fragment related data members;
    private SectionsPagerAdapter mSectionsPagerAdapter;
    private ViewPager mViewPager;

    //database related data members;
    private FirebaseDatabase firebaseDatabase;
    private FirebaseAuth firebaseAuth;
    //activity related data members;
    private String firstName;
    private CoordinatorLayout layout;
    private TabLayout tabLayout;
    private Toolbar toolbar;
    public Intent sourceIntent;
    public Bundle bundle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //initialising firebase methods;

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();


        Thread titleThread = new Thread(new Runnable() {
            @Override
            public void run() {
                //activity specific methods;
                sourceIntent = getIntent();
                bundle = sourceIntent.getExtras();
                String userId = bundle.getString("userId");

                firebaseDatabase.getReference("users").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        User user = dataSnapshot.getValue(User.class);
                        toolbar = findViewById(R.id.customerActivityToolbar);
                        toolbar.setTitle("Hello, " + user.firstName + "!");
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

            }
        });


        setContentView(R.layout.activity_customer);

        layout = findViewById(R.id.main_content_customer_screen);
        tabLayout = (TabLayout) findViewById(R.id.tabs);
        toolbar = findViewById(R.id.customerActivityToolbar);
        toolbar.setTitle("Hello ");
        titleThread.start();

        //instantiate the adapter for the ViewPager in the activity;
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        //set the ViewPager to the instantiated adapter;
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        mViewPager.setOffscreenPageLimit(2);

        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(mViewPager));

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.signOut();
                Toast.makeText(CustomerActivity.this, "Signed Out", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(CustomerActivity.this, MainActivity.class);
                CustomerActivity.this.finish();
                startActivity(intent);
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(CustomerActivity.this, "No user detected!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(CustomerActivity.this, "User detected!", Toast.LENGTH_LONG).show();
        }
    }

    /*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_customer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }*/

    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            switch (position) {
                case 0:
                    return Fragment.instantiate(CustomerActivity.this, PlaceOrderFragment.class.getName());
                case 1:
                    return Fragment.instantiate(CustomerActivity.this, OrderHistoryFragment.class.getName());
                case 2:
                    return Fragment.instantiate(CustomerActivity.this, AccountDetailsFragment.class.getName());
                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 3;
        }
    }
}
