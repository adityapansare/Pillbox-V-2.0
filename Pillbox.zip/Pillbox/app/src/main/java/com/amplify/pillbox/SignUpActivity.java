package com.amplify.pillbox;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SignUpActivity extends AppCompatActivity {

    EditText firstNameEditText;
    EditText lastNameEditText;
    EditText emailEditText;
    EditText phoneEditText;
    EditText ageEditText;
    EditText passwordEditText;
    TextView backArrow;
    Button submitSignUp;
    Button cancelSignUp;

    private static final String TAG = SignUpActivity.class.getSimpleName();
    private FirebaseDatabase firebaseDatabase;
    private FirebaseAuth firebaseAuth;
    private String userId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        //UI elements initialised;
        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        emailEditText = findViewById(R.id.emailSignUpEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        ageEditText = findViewById(R.id.ageEditText);
        backArrow = findViewById(R.id.backButton);
        submitSignUp = findViewById(R.id.submitSignUpButton);
        cancelSignUp = findViewById(R.id.cancelButton);
        passwordEditText = findViewById(R.id.passwordSignUpEditText);

        //logic elements initialised;
        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();

        //setting necessary listeners;
        backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SignUpActivity.this.finish();
            }
        });

        cancelSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SignUpActivity.this.finish();
            }
        });

        submitSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fName = firstNameEditText.getText().toString().trim();
                String lName = lastNameEditText.getText().toString().trim();
                String emailId = emailEditText.getText().toString().trim();
                String phoneNo = phoneEditText.getText().toString().trim();
                String ageString = ageEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();
                int age = 0;
                if(!ageString.isEmpty()){age = Integer.parseInt(ageEditText.getText().toString());}

                if (validation(phoneNo,age,password,ageString) == true) {
                    createUser();
                }
                else {
                    Toast.makeText(SignUpActivity.this, "Enter Valid Details", Toast.LENGTH_SHORT).show();
                }
            }

            //validation function;

        });

    }


    private void createUser() {
        final String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        final String firstName = firstNameEditText.getText().toString().trim();
        final String lastName = lastNameEditText.getText().toString().trim();
        final String phone = phoneEditText.getText().toString().trim();
        final int age = Integer.parseInt(ageEditText.getText().toString().trim());

        //create user;
        Task<AuthResult> authResultTask = firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (!task.isSuccessful()) {
                    Toast.makeText(SignUpActivity.this, "Check Email" + task.getException(), Toast.LENGTH_LONG).show();
                } else {
                    FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
                    userId = firebaseUser.getUid();
                    User user = new User(firstName, lastName, email, age, phone);
                    firebaseDatabase.getReference("users").child(userId).setValue(user);
                    firebaseDatabase.getReference("admins").child(userId).setValue("false");
                    Toast.makeText(SignUpActivity.this, "Set user data.", Toast.LENGTH_LONG).show();
                    Toast.makeText(SignUpActivity.this, "Created user account with email " + firebaseUser.getEmail(), Toast.LENGTH_LONG).show();
                    startNewActivity();
                }
            }

            private void startNewActivity() {
                Intent intent = new Intent(SignUpActivity.this, CustomerActivity.class);
                Bundle bundle = new Bundle();
                FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
                bundle.putString("userId", firebaseUser.getUid());
                intent.putExtras(bundle);
                startActivity(intent);
                SignUpActivity.this.finish();
            }
        });
    }


    //add other data to database under 'users' node;
    //userId = firebaseAuth.getCurrentUser().getUid();
    //User user = new User(firstName, lastName, email, age, phone);
    //mFirebaseDatabase.child(userId).setValue(user);

    private void addUserChangeListener() {
        firebaseDatabase.getReference("users").child(userId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                User user = dataSnapshot.getValue(User.class);

                if (user == null) {
                    Log.e(TAG, "User data is null.");
                    return;
                }

                Log.e(TAG, "User data was changed. " + user.firstName + ", " + user.email);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                //failed to read value;
                Log.e(TAG, "Failed to read user.", databaseError.toException());
            }
        });
    }

    public boolean validation(String phoneNo, int age, String password, String ageString ){
        int flag1 = 0,flag2=0,flag3=0,flag4=0,flag5=0,flag6=0,flag7=0;

            for (int i = 0; i < phoneNo.length(); i++) {
                if ((phoneNo.charAt(i) == ',') || (phoneNo.charAt(i) == '.')) {
                    phoneEditText.setText("");
                    phoneEditText.setHint("Phone (Only Numeric Values)");
                    phoneEditText.setHintTextColor(Color.RED);
                }else {
                    flag1 =1 ;
                }
            }



            if (ageString.isEmpty()) {
                ageEditText.setHintTextColor(Color.RED);
                ageEditText.setAlpha(0.6f);
            }else{
                flag2 = 1;
            }


            if(age>125){
                Toast.makeText(SignUpActivity.this,"User should be younger than \n125 years",Toast.LENGTH_SHORT).show();
                ageEditText.setHintTextColor(Color.RED);
                ageEditText.setAlpha(0.6f);
                ageEditText.setText("");
            }else{
                flag3 = 1;
            }



            if(age<18 ){
                Toast.makeText(SignUpActivity.this,"User should complete \n18 years of age",Toast.LENGTH_SHORT).show();
                ageEditText.setHintTextColor(Color.RED);
                ageEditText.setAlpha(0.6f);
                ageEditText.setText("");
            }else{
                flag4 =1;
            }


            if (password.isEmpty()) {
                passwordEditText.setHintTextColor(Color.RED);
                passwordEditText.setAlpha(0.6f);
            }else{
                flag5=1;

            }

            if(password.length()<8){
                passwordEditText.setText("");
                passwordEditText.setHintTextColor(Color.RED);
                passwordEditText.setHint("Minimum 8 characters");
            }else{
                flag6 = 1;
            }

            if(phoneNo.length()<10){
                phoneEditText.setText("");
                phoneEditText.setHint("Phone (minimum 10 characters)");
                phoneEditText.setHintTextColor(Color.RED);
            }else{
                flag7 = 1;
            }




        if(flag1*flag2*flag3*flag4*flag5*flag6*flag7 ==1){
            return true;
        }else{
            return false;
        }

    }


}


